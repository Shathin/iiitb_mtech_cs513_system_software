#ifndef ADMIN_CREDENTIALS
#define ADMIN_CREDENTIALS

#define ADMIN_LOGIN_ID "Spooks"
#define ADMIN_PASSWORD "66WrdC8pl7zYM" // "420boo69"

#endif